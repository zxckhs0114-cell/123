# SAN14CE 11/05 Resolver 누락 6개 Descriptor 로컬 AI 검증 작업

## 목표
11/05 `SAN14CE_KO.exe`에 맞는 Resolver를 만들기 위해 구 Resolver의 미검출 descriptor 6개(인덱스 0, 1, 2, 40, 41, 108)가 가리키는 **동일한 의미의 함수/코드 영역**을 11/05 런타임에서 확인한다.

## 먼저 구분할 사실
- Ghidra Version Tracking CSV에서 대응 함수가 확인된 것은 **0, 1, 2번 세 개**다.
- 40, 41, 108번은 기존 Ghidra exact-match CSV로 대응 함수를 찾지 못했다. 별도 정적 분석에서 후보 주소만 얻었으므로 정답으로 확정하면 안 된다.
- `04_미검증_후보DLL`의 DLL은 6개 주소의 바이트를 기존 Resolver descriptor 패턴에 반영해 140개 검색 결과가 모두 UNIQUE가 되도록 만든 **분석용 후보**다. 이 검증은 주소의 의미적 정확성이나 게임 실행/후킹 성공을 증명하지 않는다. 게임 폴더에 설치하거나 원본을 덮어쓰지 말 것.

## 현재 후보 표
| descriptor | 구버전 기준 RVA | 11/05 후보 RVA | 근거/상태 |
|---:|---:|---:|---|
| 0 | 0x10FC0 | 0x10F20 | Ghidra Exact Function Instructions; 후보 |
| 1 | 0x11290 | 0x111F0 | Ghidra Exact Function Instructions; 후보 |
| 2 | 0x18DF0 | 0x18D50 | Ghidra Exact Function Instructions; 후보 |
| 40 | 0x800030 | 0x39E160 | 호출 관계/주변 코드 기반 임시 후보; 미확정 |
| 41 | 0x801560 | 0x8039F0 | 7개 람다 타입 식별자/코드 배열 기반 임시 후보; 미확정 |
| 108 | 0x8548AF | 0x856C2F | 24개 포인터/짧은 thunk 배열의 대응 위치 기반 임시 후보; 미확정 |

모든 값은 RVA다. 절대 VA로 혼용하지 말 것.

## 포함 파일
- `01_Runtime/san14ce_runtime_0928.bin`: 구버전 런타임 이미지 덤프
- `01_Runtime/san14ce_runtime_1105.bin`: 11/05 런타임 이미지 덤프
- `02_Resolver_원본/SAN14_Resolver_CEKO_R35.3_0928.dll`: 기존 09/28 Resolver
- `02_Resolver_원본/SAN14_Resolver_CEKO_base_reference.dll`: base.zip Resolver 참고본
- `02_Resolver_원본/SAN14_ModCore.dll`: 공용 ModCore
- `03_Ghidra_분석결과/`: Ghidra 매치 CSV, 6개 후보표, descriptor 감사 CSV 및 분석 보고서
- `04_미검증_후보DLL/`: 실험 후보 Resolver + 140개 검색 검증표
- `05_분석메모/`: 40/41/108 후보를 좁힐 때 사용한 보조 결과와 검증 스크립트

## 로컬 AI에게 수행시킬 작업
1. 우선 0,1,2번의 Ghidra 매치 근거를 다시 확인하고, 새 런타임에서 old descriptor의 전체 mask/pivot 규칙을 적용해 유일 매칭되는지 독립 재검증한다.
2. 40번은 구버전 대상 함수의 입력/출력, 호출자·피호출자, 참조 데이터, 함수 경계를 확인한다. 후보 `0x39E160`을 그대로 정답 취급하지 말고 구버전 `0x800030`과 의미적으로 대응하는지 증명한다.
3. 41번은 구버전 `0x801560` 주변의 7개 람다/타입 식별자 및 관련 함수 참조를 추적하고, 11/05 후보 `0x8039F0`의 동일한 구조·참조 관계를 확인한다. 이 RVA가 함수 시작인지, 데이터/코드 스텁 중간인지 명시한다.
4. 108번은 구버전 `0x8548AF` 주변의 포인터 테이블/연속 thunk 배열 구조와 11/05 후보 `0x856C2F`를 비교한다. 24개 후보 중 어느 인덱스가 대응하는지 증명하고, relocation 처리 규칙도 검사한다.
5. 후보별로 함수/영역 시작 RVA, 끝 RVA, 바이트 길이, 마스크 적용 전후 매치 수, call xref, data xref, unwind/PDATA 유무, 주변 디스어셈블리, 대응 근거, 신뢰도를 보고한다.
6. 6개 항목의 대응이 입증되지 않으면 `UNRESOLVED`로 남긴다. 단순히 140개 검색을 UNIQUE로 만드는 목적으로 주소를 골라 넣지 않는다.
7. 의미적 대응이 입증된 경우에만 새 descriptor pattern을 만들고, Resolver 테이블 레이아웃/stride/CRC/ABI가 손상되지 않았는지 검사한 새 DLL을 별도 출력한다.
8. Windows 실제 실행과 게임 기능 검증 전에는 새 DLL을 `production`, `stable`, `ready`라고 부르지 않는다.

## 로컬 AI에 붙여 넣을 요청문
아래 문장을 그대로 사용한다.

> 이 자료만 사용해 SAN14CE 11/05용 Resolver의 미해결 descriptor 0,1,2,40,41,108을 분석해라. Ghidra CSV에서 0,1,2는 대응 후보가 이미 있지만, 40,41,108은 확정되지 않았다. 포함된 09/28·11/05 런타임 덤프, 원본 Resolver 2종, ModCore, Ghidra Version Tracking CSV와 감사 보고서를 교차 분석해라. 모든 주소는 RVA 기준으로 다뤄라. 특히 40=`0x39E160`, 41=`0x8039F0`, 108=`0x856C2F`는 임시 후보일 뿐이니 독립적으로 반증/검증해라. 후보 DLL의 140/140 UNIQUE 결과를 의미적 정답의 증거로 사용하지 마라. 각 descriptor가 구버전에서 가리키던 실제 함수/코드 영역과 11/05 후보가 동일한 역할인지 호출·데이터 참조, 제어 흐름, 함수 경계, unwind 정보, 주변 명령을 통해 입증해라. 확정되지 않는 항목은 unresolved로 남기고, 기존 게임 폴더나 파일을 수정하지 마라. 최종 답변은 6개 각각의 구버전 RVA, 11/05 대응 RVA, 구간 길이, 매치 수, 대응 근거, 신뢰도, 미해결 이유를 표로 작성해라. 새 DLL 작성은 6개 의미적 대응이 입증된 경우에만 별도 파일로 하며 원본 덮어쓰기를 금지한다.

## 주의
런타임 덤프는 PE 파일 자체가 아니라 로드 이미지 형태의 바이너리다. Ghidra에 올릴 때 ImageBase/RVA 변환을 보고서에 기재된 값과 맞춰야 한다. 09/28 Source ImageBase는 `0x7FF786370000`, 11/05 Destination ImageBase는 `0x7FF6D6F70000`이다.
