import struct,subprocess,re,bisect,os
R353='/mnt/data/san14_continuation/reference/R353_Resolver.dll'; OLD='/mnt/data/san14_continuation/reference/san14ce_runtime.bin'; NEW='/mnt/data/san14_continuation/reference/san14ce_1105_runtime.bin'

def sec(data):
 pe=struct.unpack_from('<I',data,0x3c)[0]; n=struct.unpack_from('<H',data,pe+6)[0]; opt=pe+24; sh=opt+struct.unpack_from('<H',data,pe+20)[0]
 a=[]
 for i in range(n):
  o=sh+40*i; name=data[o:o+8].rstrip(b'\0').decode(); vs,va,rs,rp=struct.unpack_from('<IIII',data,o+8);a.append((name,va,vs,rp,rs))
 return a

def rvaoff(data,r):
 s=next(s for s in sec(data) if s[1]<=r<s[1]+max(s[2],s[4])); return s[3]+r-s[1]

def pdata_funcs(data):
 s=next(s for s in sec(data) if s[0]=='.pdata'); va,vs=s[1],s[2]; e=[]
 for j in range(0,vs-11,12):
  b,en,u=struct.unpack_from('<III',data,va+j)
  if b<en:e.append((b,en))
 e.sort();return e

def find_func(funcs,t):
 starts=[x[0] for x in funcs]; i=bisect.bisect_right(starts,t)-1
 if i>=0 and funcs[i][0]<=t<funcs[i][1]: return funcs[i],i
 return None,i

def relaxed_mask(b, base_mask=None):
 fn='/tmp/longsig.bin';open(fn,'wb').write(b)
 p=subprocess.run(['objdump','-D','-b','binary','-m','i386:x86-64',fn],capture_output=True,text=True)
 mask=bytearray(base_mask if base_mask is not None else b'\xff'*len(b)); extra=[]; inst=[]
 for line in p.stdout.splitlines():
  m=re.match(r'\s*([0-9a-f]+):\s*((?:[0-9a-f]{2}\s+)+)\s*([a-z][a-z0-9.]*)\s*(.*)$',line)
  if not m:continue
  off=int(m.group(1),16);bb=bytes(int(x,16) for x in m.group(2).split());ops=m.group(4); mn=m.group(3)
  xs=[]
  if len(bb)>=5 and bb[0] in (0xe8,0xe9) and len(bb)==5:xs=list(range(off+1,off+5))
  elif len(bb)>=2 and (bb[0]==0xeb or 0x70<=bb[0]<=0x7f or 0xe0<=bb[0]<=0xe3):xs=[off+1]
  elif len(bb)>=6 and bb[0]==0x0f and 0x80<=bb[1]<=0x8f:xs=list(range(off+2,off+6))
  if '(%rip)' in ops and len(bb)>=4:xs += list(range(off+len(bb)-4,off+len(bb)))
  for x in xs:
   if 0<=x<len(mask):mask[x]=0;extra.append(x)
  inst.append((off,bb,mn,ops))
 return mask,sorted(set(extra)),inst

rd=open(R353,'rb').read(); old=open(OLD,'rb').read(); new=open(NEW,'rb').read(); newtextsec=next(s for s in sec(new) if s[0]=='.text'); textva,textvs=newtextsec[1],newtextsec[2];text=new[textva:textva+textvs]
funcs=pdata_funcs(old); rfuncs=pdata_funcs(new)
for idx,t in [(0,0x10fc0),(1,0x11290),(2,0x18df0),(40,0x800030),(41,0x801560),(108,0x8548af)]:
  o=rvaoff(rd,0x37e0+idx*0x220); siglen=struct.unpack_from('<I',rd,o)[0]; po,pl=struct.unpack_from('<II',rd,o+0x10); pat=rd[o+0x18:o+0x18+siglen]; origmask=rd[o+0x11c:o+0x11c+siglen]
  ff,i=find_func(funcs,t)
  if ff: start,end=ff
  else:
   # descriptor 41 sits before a sequence of leaf getters: include the following non-leaf function through its end
   j=i+1
   if j>=len(funcs): print('no following');continue
   start,end=funcs[j]
   start=t
  if idx in (0,1,2,40): start=t # signatures begin function entry; use entire function from signature
  if idx==41: start=t
  if idx==108: start=t
  blob=old[start:end]
  base_mask=bytearray(b'\xff'*len(blob))
  # retain resolver's original wildcard mask for initial descriptor bytes
  base_mask[:siglen]=origmask
  mask,extra,inst=relaxed_mask(blob,base_mask)
  runs=[]; j=0
  while j<len(mask):
   if mask[j]:
    k=j
    while k<len(mask) and mask[k]: k+=1
    runs.append((k-j,j,blob[j:k])); j=k
   else: j+=1
  runlen,runoff,runbytes=max(runs)
  hits=[]; pos=0
  while True:
   f=text.find(runbytes,pos)
   if f<0: break
   p0=f-runoff
   if p0>=0 and p0+len(blob)<=len(text) and all(not mask[j] or text[p0+j]==blob[j] for j in range(len(blob))): hits.append(textva+p0)
   pos=f+1
  print(f'IDX {idx}: range old {start:#x}-{end:#x} len={len(blob):#x}, descriptor={siglen}, added={len(blob)-siglen}, extra_mask={len(extra)}, fixed={sum(x!=0 for x in mask)}, new_hits={len(hits)}')
  print(' hits',','.join(hex(x) for x in hits[:50]))
  # for each candidate, find containing pdata function, if any
  for h in hits[:20]:
   m,k=find_func(rfuncs,h)
   if m: print('  ',hex(h),'function',hex(m[0]),hex(m[1]),'offset',hex(h-m[0]))
