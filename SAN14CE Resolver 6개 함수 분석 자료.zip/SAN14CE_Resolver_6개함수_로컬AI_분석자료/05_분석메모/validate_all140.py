import struct, pathlib, hashlib, csv, json
ROOT=pathlib.Path('/mnt/data/san14_continuation')
res_path=ROOT/'resolver_from_r353.dll'
rt_path=ROOT/'reference/san14ce_1105_runtime.bin'
res=bytearray(res_path.read_bytes())
rt=rt_path.read_bytes()

def parse_pe(buf):
    pe=struct.unpack_from('<I',buf,0x3c)[0]
    n=struct.unpack_from('<H',buf,pe+6)[0]
    osz=struct.unpack_from('<H',buf,pe+20)[0]
    so=pe+24+osz
    sec={}
    for i in range(n):
        o=so+i*40
        name=buf[o:o+8].split(b'\0')[0].decode()
        vs,va,rs,rp=struct.unpack_from('<IIII',buf,o+8)
        sec[name]=(va,vs,rp,rs)
    return pe,sec

_,rsecs=parse_pe(res)
_,tsecs=parse_pe(rt)
print('resolver sections',rsecs)
print('target sections',tsecs)
# R353 resolver .rodata table is at RVA 0x37E0. use RVA->file offset via section mapping

def rva_to_off(secs,rva):
    for name,(va,vs,rp,rs) in secs.items():
        if va <= rva < va + max(vs,rs):
            return rp+(rva-va)
    raise ValueError(hex(rva))

tva,tvs,trp,trs=tsecs['.text']
txt=rt[tva:tva+tvs]
print('target .text',hex(tva),hex(tvs),len(txt))
table_off=rva_to_off(rsecs,0x37E0)
stride=0x220
candidates={0:0x10F20,1:0x111F0,2:0x18D50,40:0x39E160,41:0x8039F0,108:0x856C2F}
# patch pattern region using absolute target RVA (runtime dump is image mapped, so direct RVA indexing)
for idx,newrva in candidates.items():
    o=table_off+idx*stride
    ln=struct.unpack_from('<I',res,o)[0]
    res[o+0x18:o+0x18+ln]=rt[newrva:newrva+ln]

# emulate resolver's two-stage search, pivot + full mask
rows=[]
for idx in range(140):
    o=table_off+idx*stride
    ln=struct.unpack_from('<I',res,o)[0]
    flags,rel_off,rel_add=struct.unpack_from('<III',res,o+4)
    pivot_off,pivot_len=struct.unpack_from('<II',res,o+0x10)
    pat=bytes(res[o+0x18:o+0x18+ln])
    mask=bytes(res[o+0x11c:o+0x11c+ln])
    if ln==0 or pivot_len==0 or pivot_off+pivot_len>ln:
        rows.append((idx,ln,pivot_off,pivot_len,flags,0,[], 'EMPTY_OR_INVALID'))
        continue
    pivot=pat[pivot_off:pivot_off+pivot_len]
    hits=[]; start=0
    while True:
        h=txt.find(pivot,start)
        if h<0: break
        cand=h-pivot_off
        if cand>=0 and cand+ln<=len(txt):
            seg=txt[cand:cand+ln]
            if all((m==0 or seg[j]==pat[j]) for j,m in enumerate(mask)):
                hits.append(tva+cand)
        start=h+1
    status='UNIQUE' if len(hits)==1 else ('MISSING' if not hits else 'AMBIGUOUS')
    rows.append((idx,ln,pivot_off,pivot_len,flags,len(hits),hits,status))

from collections import Counter
c=Counter(x[-1] for x in rows)
print('SUMMARY',dict(c))
for row in rows:
    if row[-1] != 'UNIQUE': print('BAD',row)
# also print candidate mappings resolution metadata
for idx,newrva in candidates.items():
    row=rows[idx]
    print('CANDIDATE',idx,hex(newrva),row[-2],row[-1])

# Save binary candidate for analysis only if all 140 are unique.
if len(rows)==140 and all(x[-1]=='UNIQUE' for x in rows):
    out=ROOT/'SAN14_Resolver_CEKO_1105_candidate.dll'
    out.write_bytes(res)
    print('SAVED',out,'sha256',hashlib.sha256(res).hexdigest())
else:
    print('NOT SAVED: all 140 not uniquely resolved')
with open(ROOT/'resolver_1105_all140_validation.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['index','length','pivot_offset','pivot_length','reloc_flag','match_count','match_rva','status'])
    for idx,ln,po,pl,flags,n,hits,status in rows:
        w.writerow([idx,ln,po,pl,flags,n,';'.join(hex(x) for x in hits),status])
