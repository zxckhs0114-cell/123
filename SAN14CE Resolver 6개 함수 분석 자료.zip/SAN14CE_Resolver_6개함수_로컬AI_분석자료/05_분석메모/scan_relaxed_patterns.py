import struct, subprocess, re, os
R353='/mnt/data/san14_continuation/reference/R353_Resolver.dll'
OLD='/mnt/data/san14_continuation/reference/san14ce_runtime.bin'
NEW='/mnt/data/san14_continuation/reference/san14ce_1105_runtime.bin'

def get_sections(data):
    pe=struct.unpack_from('<I',data,0x3c)[0]; n=struct.unpack_from('<H',data,pe+6)[0]; opt=pe+24; osz=struct.unpack_from('<H',data,pe+20)[0]; sh=opt+osz
    out=[]
    for i in range(n):
        o=sh+i*40; name=data[o:o+8].rstrip(b'\0').decode(errors='replace'); vs,va,rs,rp=struct.unpack_from('<IIII',data,o+8); out.append((name,va,vs,rp,rs))
    return out

def rva_to_raw(d, rva, secs):
    for name,va,vs,rp,rs in secs:
        if va <= rva < va + max(vs,rs):
            return rp+(rva-va)
    raise ValueError(hex(rva))

rd=open(R353,'rb').read(); secs=get_sections(rd)
ro=next(s for s in secs if s[0]=='.rodata')
def rva(r):return rva_to_raw(rd,r,secs)
old=open(OLD,'rb').read(); new=open(NEW,'rb').read(); newsecs=get_sections(new); textsec=next(s for s in newsecs if s[0]=='.text'); textva,textvs=textsec[1],textsec[2]; text=new[textva:textva+textvs]

# source resolver descriptor array: 140 records, 0x220 stride, starts at RVA 0x37e0
for idx, old_rva in [(0,0x10fc0),(1,0x11290),(2,0x18df0),(40,0x800030),(41,0x801560),(108,0x8548af)]:
    o=rva(0x37e0+idx*0x220)
    length=struct.unpack_from('<I',rd,o)[0]; po,pl=struct.unpack_from('<II',rd,o+0x10)
    pat=bytearray(rd[o+0x18:o+0x18+length]); mask=bytearray(rd[o+0x11c:o+0x11c+length])
    # disassemble from old runtime image bytes at signature start
    sl=old[old_rva:old_rva+length]
    fn=f'/tmp/sig_{idx}.bin'; open(fn,'wb').write(sl)
    p=subprocess.run(['objdump','-D','-b','binary','-m','i386:x86-64','--adjust-vma=0x0',fn],capture_output=True,text=True)
    extra=[]; insns=[]
    for line in p.stdout.splitlines():
        m=re.match(r'\s*([0-9a-f]+):\s*((?:[0-9a-f]{2}\s+)+)\s*([a-z][a-z0-9.]*)\s*(.*)$',line)
        if not m: continue
        off=int(m.group(1),16); b=bytes(int(x,16) for x in m.group(2).split()); mn=m.group(3); ops=m.group(4)
        insns.append((off,b,mn,ops))
        # mask PC-relative branch displacement or RIP-relative disp32
        if len(b)>=2 and (b[0] in (0xe8,0xe9) and len(b)==5):
            extra.extend(range(off+1,off+5))
        elif len(b)>=2 and (b[0]==0xeb or 0x70<=b[0]<=0x7f or 0xe0<=b[0]<=0xe3):
            extra.append(off+1)
        elif len(b)>=6 and b[0]==0x0f and 0x80<=b[1]<=0x8f:
            extra.extend(range(off+2,off+6))
        elif '(%rip)' in ops and len(b)>=4:
            extra.extend(range(off+len(b)-4,off+len(b)))
    for x in extra:
        if 0<=x<length: mask[x]=0
    # masked scan in new .text (mask !=0 -> exact byte)
    hits=[]
    for i in range(0,len(text)-length+1):
        # quick exact compare in chunks via bytes loop
        ok=True
        for j in range(length):
            if mask[j] and text[i+j]!=pat[j]: ok=False;break
        if ok: hits.append(textva+i)
    print(f'IDX {idx}: len={length} old={old_rva:#x} pivot={po:#x}+{pl:#x}; extra_wildcards={len(extra)} hits={len(hits)}')
    print(' extra offsets:',','.join(hex(x) for x in extra))
    print(' hit RVAs:',','.join(hex(x) for x in hits[:30]))
    print(' disassembly:')
    for off,b,mn,ops in insns:
        print(f'  {off:04x} {b.hex(" "):30s} {mn:8s} {ops}')
