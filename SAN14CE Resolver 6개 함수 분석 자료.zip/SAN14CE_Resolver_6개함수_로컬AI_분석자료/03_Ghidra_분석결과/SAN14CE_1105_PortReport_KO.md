# SAN14CE 2026-11-05 1~24 마스터 통합 포팅 보고서

작성일: 2026-11-06  
대상 실행 파일: `SAN14CE_KO.exe`  
SHA-256: `782cf229a56cdde2b95399e0e7536740b3f5e96bea702679365e4dad061abdce`  
PE timestamp: `0x6AD06F53` / SizeOfImage: `0x02A02000`

## 1. 최종 패키지 구성

이번 마스터 안전 진행판은 24개 모드의 번호표와 작업 현황을 하나로 모으고, 현재 정적 이식이 검증된 네 가지 파일/리소스 모드만 한 번에 설치·복구하도록 만들었다.

| 모드 | 기능 | 처리 |
|---:|---|---|
| 15 | 경험치 능력치 성장 억제 | 설치 가능 |
| 17 | 고운 바탕 글꼴 | 설치 가능 |
| 21 | 수여 능력치 증가 억제 | 설치 가능 |
| 23 | 주메뉴·버튼 그래픽 v30 | 설치 가능 |
| 24 | 노년 얼굴 전환 방지 | DLL 소스/빌드 보관, 설치 제외 |
| 그 외 19개 | DLL/후킹 기능 | 미포팅, 설치 제외 |

**이 파일은 1~24번 모든 기능이 완성된 최종 기능판이 아니다.** 검증되지 않은 DLL을 활성화하지 않는 방식으로 단일 설치/제거 패키지를 정리한 안전 진행판이다.

## 2. 이번 설치팩에서 변경한 안전 설계

앞서 만든 단독 시험팩은 24번 Resolver의 6개 미해결 슬롯을 다른 슬롯 주소에 임시 별칭 연결하고, 이를 위해 기존 DLL 모듈 INI를 비활성화하는 구조였다. 이 구조는 24번 단독 시험에만 해당하며 전체 통합판에 넣기 부적절하다.

이번 마스터팩에서는 아래 파일/설정을 설치하지 않는다.

- `SAN14_ModCore.dll`
- `SAN14_Resolver_CEKO.dll`
- `SAN14_NoAgingFace_1105.dll` 및 모듈 INI
- `dxgi.dll`, `version.dll`, `dinput8.dll`
- 기존 `SAN14Mods/modules` 내 다른 모듈 INI

따라서 기존 DLL 모드 등록과 로더를 변경하거나 비활성화하지 않는다. 모드 24는 `staging/mode24`에 소스와 빌드 결과만 보관한다.

## 3. 11/05 원본에서 재생성한 데이터/리소스

### 3.1 모드 15 — 경험치 능력치 성장 억제

- 대상: `0000\experience_data_exce.bin`
- 11/05 원본 SHA-256: `9dc23c204be26108326d61907a7c06f675abd2828f163582908a7f537916b526`
- 출력 SHA-256: `ecb019d4ffce3e722df7eb4685b986af4c6e55e2035836fbffd704094b638221`
- 원본 파일 기준으로 변환 결과를 재생성하고 해시를 검증했다.
- 모드 1 설정 UI가 미포팅이므로 설치하면 항상 적용된다.

### 3.2 모드 17 — 고운 바탕 글꼴

- 대상: `0002\RRPreview.rdb`
- 원본 SHA-256: `a9bb649b4405a065f6330e70975a85a559cb8523af6c0df3ec63ea16685c6ae6`
- 출력 SHA-256: `752a4b52130354bf16e124919f9ba82230581ebef2da4e3abdea51ea536865ab`
- 2,082개 레코드 중 대상 참조 2개만 변경, 나머지 2,080개 유지.
- `RRPreview.rdb.bin99`는 11/05 제공 원본 SHA-256 `768fa088143ac3916dbb9e76ecf720f5252139900a886c65e879c16cdfbe27bc`를 확인하고 원본을 그대로 사용한다.

### 3.3 모드 21 — 수여 능력치 증가 억제

- 대상: `0010_KO\fixdataexce.s14`
- 원본 SHA-256: `bbcf4f5023b9e870f0c51e6f37b0f95401abe6e32ec29fddd75fdba52d4c07b7`
- 출력 SHA-256: `70342a6e733d64a7e6dbb62634fe4d36cd965c1ae8223890c0ded7e78ecbd65d`
- 11/05 원본을 직접 해제·수정·재인코딩했고 299개 지정 필드를 0으로 재해제 확인했다.
- 같은 변환을 구버전 원본에 적용했을 때 공식 수정본과 해시가 일치해 변환 로직을 대조했다.
- 모드 1 설정 UI가 미포팅이므로 설치하면 항상 적용된다.

### 3.4 모드 23 — 주메뉴·버튼 그래픽 v30

- 대상: `0002\ScreenLayout.rdb`
- 원본 SHA-256: `8c017045fd39bb4e597dca66a825b788e0dc660b0a323529b846f9600b25190f`
- 출력 SHA-256: `713d929b835a8ccfea9eb66518eed55257a44df67f69a4dcc481d4fea2dce60b`
- 18,046개 레코드 중 9개 참조만 변경, 나머지 18,037개 유지.
- `ScreenLayout.rdb.bin3375` 추가 파일 SHA-256: `6f3655d2c0f345bb19e555ba02edcb1d5ffc8d6118dab71d05a12d943461aac4`.
- `ScreenLayout.rdb.bin24`는 SHA-256 `4502fdaf247100c2b9cc8052f529bbf041569cf754639ee85ccdec3a581ce7a2`를 사전 확인하고 변경하지 않는다.

## 4. base.zip Resolver 분석 반영

사용자가 제공한 `base.zip`을 분석하고 원본 파일을 `reference/base.zip` 및 `reference/basezip/`에 보관했다.

| 항목 | base.zip Resolver | R35.3(09/28) Resolver | 11/05 EXE |
|---|---:|---:|---:|
| 대상 EXE timestamp | `0x6A6D9F72` | `0x6A983C25` | `0x6AD06F53` |
| SizeOfImage | `0x029FF000` | `0x029FF000` | `0x02A02000` |
| Resolver bytes | 84,480 | 84,480 | — |

- Resolver 엔진 `.text`는 양쪽 비교에서 3바이트 차이이며 나머지 바이트는 동일했다.
- `.rodata`에는 총 53바이트 차이가 있었다.
- 140개 메인 descriptor record 중 134개가 동일하고, 인덱스 `0, 1, 2, 40, 41, 108`의 6개가 달랐다. 정확한 pivot+전체 mask 검색에서도 11/05 런타임 이미지에서 동일한 6개가 미검출됐다.
- 두 패키지의 `SAN14_ModCore.dll`은 SHA-256 `7f839777153448a0d0be71731ae1bce98fb3288a14fcbbc67b55366bae283230`으로 동일했다.
- base.zip Resolver에 있는 초기 탐색 시그니처 8개는 이전 별도 검사에서 11/05 런타임 이미지에 각각 유일하게 매칭된 것으로 기록되어 있다.

하지만 Resolver가 출력하는 전체 함수 주소표, 모듈별 후킹 지점, 호출 규약, 구조체 오프셋까지 신버전에서 검증한 것은 아니다. 본문 4.1의 정확한 Resolver 검색 규칙 재현 결과, R35.3의 09/28 대조군은 140개 모두 유일 매칭했고 11/05에서는 134 유일·6 미검출·0 중복이었다. 특히 fingerprint가 11/05 EXE와 다르고 SizeOfImage도 다르기 때문에 base.zip Resolver를 현재 게임에 설치하지 않는다. 6개 별칭 슬롯을 사용하는 실험용 Resolver 역시 본 마스터팩에서 제외했다.

### 4.1 실제 140개 descriptor의 Resolver 검색 규칙 재현

Resolver 검색 함수를 역어셈블해 탐색 흐름을 재현했다. descriptor의 `offset`은 전체 서명 시작점이 아니라 빠른 탐색용 pivot 구간의 시작 위치다. Resolver는 `pattern[offset:offset+pivot_length]`를 검색한 뒤, 후보 주소에서 `offset`만큼 되돌아가 전체 서명 `pattern[0:signature_length]`를 mask에 따라 다시 비교한다. 제공된 140개 descriptor의 pivot 바이트는 모두 고정 mask(`0xFF`)임을 확인했다.

| Resolver descriptor 세트 | 09/28 런타임 이미지 | 11/05 런타임 이미지 |
|---|---:|---:|
| base.zip(09/10) Resolver | 유일 134 / 미검출 6 / 중복 0 | 유일 134 / 미검출 6 / 중복 0 |
| R35.3(09/28) Resolver | 유일 140 / 미검출 0 / 중복 0 | 유일 134 / 미검출 6 / 중복 0 |

R35.3 Resolver의 09/28 descriptor 140개가 09/28 이미지에서 모두 유일하게 매칭된 것을 대조군으로 사용했다. 이로써 검색 구현이 구버전 정상 대상 빌드에 대해 기대한 결과를 재현하는 것을 확인했다. 반면 11/05에서는 base.zip과 R35.3 descriptor 세트 양쪽에서 동일하게 `0, 1, 2, 40, 41, 108`의 여섯 항목이 미검출됐다. base.zip은 09/28 이미지에서도 같은 여섯 항목이 미검출되어, 사용자가 제공한 09/10 계열 Resolver와 09/28 R35.3 Resolver의 차이도 확인된다.

**실제 초기화 영향:** Resolver 초기화 코드는 140개 descriptor를 순회하며 검색 함수가 null을 반환하면 공통 실패 경로로 분기한다. 따라서 11/05에서 6개 함수 서명이 미검출된 현재 상태로는 resolver가 성공 초기화될 수 없다. 이 주소를 인접 함수나 slot 3 등 다른 descriptor의 주소로 임시 대체하는 방식은 사용하지 않는다.

**해석상 한계:** 위 결과는 제공된 런타임 이미지 덤프의 `.text` 범위에 대한 정적 시그니처 검색이다. 실제 게임 프로세스에서 성공적으로 초기화됐다는 뜻은 아니다. 실제 실행·후킹 동작 검증도 별도로 필요하다.

런타임 이미지 SHA-256:
- 09/28: `65268ef1ddbe1f68b0d223b020cfb7278ef5ede515002901660d7c0e72d9a4ed`
- 11/05: `2398fe50603ad1194c52ec824b941effaec61dbe7053b99c6941eb4ebbb06c9c`

각 descriptor의 서명 길이, 고정 mask 바이트 수, pivot 구간, 09/28·11/05별 매치 수 및 RVA, descriptor record SHA-256은 `reports/RESOLVER_SIGNATURE_AUDIT.csv`에 기록했다.

### 4.2 초기 탐색 서명 8개와의 구분

초기 탐색/부트스트랩 서명 8개의 11/05 유일 매칭은 Resolver 진입부를 찾는 별도 검사다. 본문의 140개 메인 함수 descriptor 검색을 대신하지 않는다. 따라서 초기 8개가 일치하더라도 140개 중 6개가 미검출이면 Resolver 초기화는 통과하지 못한다.

## 5. base.zip 안의 모듈 자료

base.zip에는 다음이 들어 있다.

- `SAN14_IntegratedConvenience.dll`
- `SAN14_ModCore.dll`
- `SAN14_Resolver_CEKO.dll`
- `SAN14_Compat20_Entry.dll`
- `SAN14_AutoPersonnelRepair.dll`
- `SAN14_DualCreditSaveRepair.dll`
- `SAN14_SettingsHelpScenic.dll` (기본/내정 버전)

이 모듈들이 1~24 중 일부 기능과 관련될 가능성은 있지만, ZIP 내 파일 이름만으로 새 번호와 1:1 대응하거나 11/05 호환성을 보장할 수 없다. 따라서 원본 ZIP은 참조 폴더에만 보관하고 설치하지 않았다.

## 6. 모드 24 상태

`SAN14_NoAgingFace_1105.dll`은 11/05 EXE fingerprint 및 얼굴 관련 19개 표 항목을 대상으로 만든 개발 DLL이다. DLL 파일 자체와 C 소스/DEF를 `staging/mode24`에 보존했다.

그러나 Resolver가 필요한 함수 6개를 확정하지 못한 상태이고, base.zip Resolver의 fingerprint도 11/05와 다르다. 따라서 DLL과 임시 Resolver를 자동 설치하지 않는다. 이전 임시 별칭 Resolver는 인덱스 0,1,2,40,41,108을 인덱스 3 주소에 연결한 실험품이므로 배포/일반 사용 대상에서 제외했다.

## 7. 설치기/제거기

`install.cmd`는 Windows PowerShell 5.1에서 `install.ps1`을 실행한다.

설치 전 검사:
1. 게임/런처 프로세스가 종료됐는지 확인.
2. EXE SHA-256이 정확히 11/05 기준인지 확인.
3. 모드 15·17·21·23의 현재 원본 SHA-256 확인.
4. 글꼴/그래픽 보조 리소스 SHA-256 확인.
5. 출력 파일 및 추가 bin3375 SHA-256 확인.
6. 이전 시험팩 백업 폴더가 남았는지 확인.

설치 동작:
- 원본 파일을 마스터 백업 폴더에 복사하고 해시 검증.
- 4개 변경 파일과 23번 bin3375만 설치.
- Resolver/Core/로더/모듈 INI 및 기존 DLL 설정은 건드리지 않음.
- 설치 상태 JSON을 저장.

제거 동작:
- 설치 파일과 원본 백업 해시를 모두 사전 검사.
- 사용자 변경 또는 백업 손상이 있으면 아무 파일도 복구하지 않고 중단.
- 검증 통과 시 원본 파일로 복구하고 백업 폴더를 유지.

Windows PowerShell 실행 테스트는 이 Linux 작업 환경에서 수행하지 못했다. 스크립트는 정적 검토만 했다.

## 8. 미완료 모드 및 이유

1~14, 16, 18~20, 22번은 DLL 후킹/메모리 패치/UI 구조를 사용한다. 구버전 DLL 바이너리만 복사하면 해결되지 않으며, 11/05 runtime에서 실제 함수 시그니처·주소·호출 규약·네이티브 레이아웃을 각각 확인해야 한다. 일부 구버전 DLL에는 이미 “unsupported game build”, “signature mismatch”, “no patches applied”와 같은 fail-closed 문자열이 있어, 해당 모듈이 실행 중 후킹을 건너뛰도록 설계됐음을 확인했다.

현재 제공 자료만으로 안전하게 이식해 활성화한 모드는 네 가지 파일/리소스 모드다. 나머지 DLL 모드를 활성화했다고 표시하지 않는다.

## 9. 검증 매트릭스

| 검증 | 상태 |
|---|---|
| 4개 payload SHA-256 | 통과 |
| 11/05 EXE fingerprint 일치 여부 | 설치기에서 검사하도록 구성 |
| RDB 레코드 구조/변경 개수 | 통과(정적) |
| fixdata 299 필드 재해제 검사 | 통과(정적) |
| Resolver base/old binary diff | 통과(정적) |
| ZIP CRC 및 내부 manifest | 패키지 빌드 시 검사 |
| Windows PowerShell 설치 실행 | 미실시 |
| 게임 실행 및 실제 UI/효과 | 미실시 |
| 모드 24 얼굴 전환 실제 동작 | 미실시/설치 제외 |

## 10. 결론

이번에는 앞선 위험한 단독시험 설치 구성을 일반 통합팩에서 제거하고, 검증된 15·17·21·23번만 설치하는 단일 마스터 안전 진행판을 작성했다. 기존 DLL/Resolver/INI/로더를 변경하지 않으므로 이전 시험판보다 설치 영향 범위를 좁혔다.

하지만 1~24번 전체 기능을 하나의 파일에서 전부 활성화한 완성판은 아니다. 1~14,16,18~20,22번의 신버전 후킹 포팅과 24번 Resolver 완성이 남아 있고, 실제 Windows 게임 테스트도 필요하다.
