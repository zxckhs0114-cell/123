# Ghidra Version Tracking 결과 분석

## 내보낸 자료 요약
- 전체 CSV 행: 76,491
- Type=Function 행: 51,977
- 중복 알고리즘 행을 제거한 고유 Source-Destination 함수 매치: 25,046쌍
- 알고리즘 행 수: Exact Function Instructions 23,039 / Exact Function Instructions 21,781 / Exact Function Bytes 6,232 / Exact Symbol Name 925
- 점수 1.0은 Ghidra가 해당 비교 알고리즘 기준으로 정확 일치 결과를 냈다는 뜻이며, 각 Resolver descriptor의 signature가 신버전에서 그대로 검색된다는 뜻은 아니다.

## PE ImageBase 및 주소 변환
- 09/28 Source ImageBase: `0x7FF786370000`
- 11/05 Destination ImageBase: `0x7FF6D6F70000`
- RVA 계산은 각 절대 주소에서 해당 ImageBase를 빼서 수행했다.

## 6개 미검출 descriptor 추적
| Descriptor | 09/28 signature RVA | Source 함수 RVA | 함수 내부 offset | Destination 함수 RVA | 계산한 11/05 후보 RVA | 알고리즘 |
|---:|---:|---:|---:|---:|---:|---|
| 0 | `0x10FC0` | `0x10DA0` | `0x220` | `0x10D00` | `0x10F20` | Exact Function Instructions |
| 1 | `0x11290` | `0x11230` | `0x60` | `0x11190` | `0x111F0` | Exact Function Instructions |
| 2 | `0x18DF0` | `0x18700` | `0x6F0` | `0x18660` | `0x18D50` | Exact Function Instructions |
| 40 | `0x800030` | 미확인 | — | 미확인 | 미확인 | exact export에 함수 구간 매치 없음 |
| 41 | `0x801560` | 미확인 | — | 미확인 | 미확인 | exact export에 함수 구간 매치 없음 |
| 108 | `0x8548AF` | 미확인 | — | 미확인 | 미확인 | exact export에 함수 구간 매치 없음 |

0~2번의 새 RVA는 매칭된 함수 시작점 간의 내부 offset을 옮겨 계산한 **정적 후보**다. 0번은 Mnemonics 매치이므로 바이트가 다를 수 있고, 1·2번도 새 descriptor pattern을 재생성해 전체 mask와 pivot 규칙으로 11/05 `.text`에서 유일성을 재검사해야 한다. 따라서 세 주소를 Resolver에 확정 반영하지 않았다.

40·41·108번은 현재 내보낸 exact 매치 CSV에서 서명 시작점을 포함하는 일치 함수 구간을 찾지 못했다. 다음 추적에는 Ghidra에서 Similar Function Instructions/Mnemonics, Function Reference Match 및 decompiler 실패 함수의 Listing/Function Graph 검토가 필요하다.

## 결론
Ghidra CSV는 전역 함수 관계를 좁히는 데 유용하지만 Resolver 140개 중 6개를 자동으로 완전히 해결하지는 못했다. 0~2번은 후보 RVA를 얻었고, 40·41·108번은 추가 정적/동적 추적이 필요하다.
